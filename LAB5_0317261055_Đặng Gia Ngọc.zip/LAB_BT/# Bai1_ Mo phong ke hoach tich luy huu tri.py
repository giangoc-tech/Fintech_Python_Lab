# BÀI TẬP 1: MÔ PHỎNG KẾ HOẠCH TÍCH LŨY HƯU TRÍ

# 1. Khởi tạo các dữ liệu ban đầu
tuoi = 25                  # Tuổi bắt đầu tích lũy
so_du = 0.0                # Số tiền hiện có ban đầu
tien_gui = 60000000.0      # Tiền gửi của năm đầu tiên
lai_suat = 0.10            # Lãi suất đầu tư 10% mỗi năm
tang_tien_gui = 0.08       # Tiền gửi tăng 8% mỗi năm
muc_tieu = 10000000000.0  # Mục tiêu 10 tỷ đồng
nam = 0                    # Đếm số năm tích lũy

print('=== BÁO CÁO MÔ PHỎNG KẾ HOẠCH HƯU TRÍ TỰ ĐỘNG ===')
print(f'Mục tiêu tài sản: {muc_tieu:,.0f} VNĐ')
print('-' * 100)
print(f"{'Năm':<5} | {'Tuổi':<5} | {'Tiền gửi mới':>20} | {'Tiền lãi trong năm':>21} | {'Tổng tài sản cuối năm':>26}")
print('-' * 100)

# 2. Tiếp tục tích lũy khi số dư chưa đạt mục tiêu
while so_du < muc_tieu:
    nam += 1                            # Sang năm tích lũy tiếp theo
    tien_lai = so_du * lai_suat        # Tính lãi dựa trên số dư đầu năm
    so_du = so_du + tien_lai + tien_gui  # Cộng cả tiền lãi và tiền gửi mới

    # In thông tin của năm hiện tại
    print(f'{nam:<5} | {tuoi:<5} | {tien_gui:>16,.0f} VNĐ | {tien_lai:>17,.0f} VNĐ | {so_du:>22,.0f} VNĐ')

    # Chuẩn bị dữ liệu cho năm sau
    if so_du < muc_tieu:
        tien_gui = tien_gui * (1 + tang_tien_gui)
        tuoi += 1

# 3. Thông báo kết quả
print('-' * 100)
print(f'KẾT LUẬN: Đạt mục tiêu sau {nam} năm tích lũy (năm ghi tuổi {tuoi}).')
print(f'Tổng tài sản cuối năm: {so_du:,.0f} VNĐ')
