# BÀI TẬP 2: TỰ ĐỘNG HÓA ĐỊNH GIÁ TRÁI PHIẾU DOANH NGHIỆP

# 1. Khởi tạo các thông số của trái phiếu
F = 1000000.0       # Mệnh giá 1 triệu VNĐ
c = 0.09            # Lãi suất coupon 9%/năm
N = 10              # Thời hạn trái phiếu 10 năm
y = 0.085           # Lợi suất kỳ vọng 8.5%/năm
C = F * c           # Tiền lãi coupon nhận mỗi năm
tong_pv_coupon = 0.0 # Tổng giá trị hiện tại của các khoản coupon

print('=== BẢNG ĐỊNH GIÁ TRÁI PHIẾU DOANH NGHIỆP ===')
print(f'Mệnh giá: {F:,.0f} VNĐ')
print(f'Lãi coupon mỗi năm: {C:,.0f} VNĐ')
print('-' * 48)
print(f"{'Năm':<6} | {'Coupon (VNĐ)':>16} | {'PV coupon (VNĐ)':>17}")
print('-' * 48)

# 2. Dùng vòng lặp for để tính PV coupon từ năm 1 đến năm 10
for t in range(1, N + 1):
    pv_c = C / ((1 + y) ** t)    # Chiết khấu coupon của năm t
    tong_pv_coupon += pv_c        # Cộng dồn giá trị hiện tại
    print(f'{t:<6} | {C:>16,.0f} | {pv_c:>17,.0f}')

# 3. Tính giá trị hiện tại của mệnh giá được hoàn lại cuối kỳ
pv_f = F / ((1 + y) ** N)

# 4. Tính giá lý thuyết của trái phiếu
gia_trai_phieu = tong_pv_coupon + pv_f

print('-' * 48)
print(f'Tổng PV coupon: {tong_pv_coupon:,.0f} VNĐ')
print(f'PV mệnh giá gốc: {pv_f:,.0f} VNĐ')
print(f'Giá lý thuyết trái phiếu: {gia_trai_phieu:,.0f} VNĐ')

# 5. Phân loại trái phiếu theo giá so với mệnh giá
if gia_trai_phieu > F + 0.01:
    print('Kết luận: Trái phiếu CAO HƠN MỆNH GIÁ (Premium).')
elif gia_trai_phieu < F - 0.01:
    print('Kết luận: Trái phiếu THẤP HƠN MỆNH GIÁ (Discount).')
else:
    print('Kết luận: Trái phiếu ĐÚNG MỆNH GIÁ (Par).')
