# BÀI TẬP 3: MA TRẬN MÔ PHỎNG RỦI RO DANH MỤC

# 1. Khai báo giá trị danh mục và các kịch bản biến động
von_goc = 20.0                       # Vốn ban đầu: 20 tỷ VNĐ
thay_doi_ty_gia = [-0.03, 0, 0.03]  # Tỷ giá: -3%, 0%, +3%
thay_doi_lai_suat = [-0.02, -0.01, 0.01, 0.02]  # Lãi suất: -2%, -1%, +1%, +2%

print('=== MA TRẬN PHÂN TÍCH ĐỘ NHẠY GIÁ TRỊ DANH MỤC (TỶ VNĐ) ===')
print(f'Vốn danh mục ban đầu: {von_goc:.2f} tỷ VNĐ')
print('-' * 78)
print(f"{'Lãi suất / Tỷ giá':<24} | {'-3.0%':>13} | {'0.0%':>13} | {'+3.0%':>13}")
print('-' * 78)

# 2. Vòng lặp ngoài duyệt từng mức thay đổi lãi suất (dòng)
for ir in thay_doi_lai_suat:
    dong = f'Lãi suất: {ir:+.1%}'

    # 3. Vòng lặp trong duyệt từng mức thay đổi tỷ giá (cột)
    for ex in thay_doi_ty_gia:
        # Công thức giá trị danh mục mới trong đề
        von_moi = von_goc * (1 + 1.5 * ex - 2.0 * ir)
        dong += f' | {von_moi:>10.2f} tỷ'

    # 4. In toàn bộ giá trị của dòng hiện tại
    print(dong)

print('-' * 78)
# Lưu ý: Bảng mẫu của đề có số không khớp công thức.
# Chương trình này sử dụng đúng công thức V_moi = V_goc * (1 + 1.5*Ex - 2.0*Ir).
