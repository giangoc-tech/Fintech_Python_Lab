# =====================================================
# BAI 2: HAM CHAM DIEM TIN DUNG TU DONG
# =====================================================

def credit_score(income, credit_history_years, has_bad_debt=False):
    """
    Phan loai rui ro tin dung cua khach hang.

    Tham so:
        income (float): Thu nhap hang thang (VND).
        credit_history_years (float): So nam lich su tin dung.
        has_bad_debt (bool): Co no xau hay khong, mac dinh False.

    Tra ve:
        str: 'Reject', 'High Risk', 'VIP' hoac 'Standard'.
    """
    # Neu khach hang co no xau thi tu choi ngay
    if has_bad_debt == True:
        return "Reject"

    # Thu nhap thap hoac lich su tin dung duoi 1 nam
    if income < 10000000 or credit_history_years < 1:
        return "High Risk"

    # Thu nhap cao va lich su tin dung tu 3 nam tro len
    if income >= 20000000 and credit_history_years >= 3:
        return "VIP"

    # Cac truong hop con lai
    return "Standard"


# Chuong trinh chay thu cac truong hop
print("=== BAI 2: CHAM DIEM TIN DUNG ===")
print("Khach hang A (co no xau):", credit_score(30000000, 5, True))
print("Khach hang B (thu nhap thap):", credit_score(8000000, 2))
print("Khach hang C (du dieu kien VIP):", credit_score(25000000, 4))
print("Khach hang D (thong thuong):", credit_score(15000000, 2))
