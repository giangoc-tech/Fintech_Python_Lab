# =====================================================
# BAI 1: HAM NIEN KIM TRA GOP (EMI)
# =====================================================

def calculate_emi(principal, annual_rate, months):
    """
    Tinh so tien tra gop hang thang theo cong thuc EMI.

    Tham so:
        principal (float): So tien vay ban dau (VND).
        annual_rate (float): Lai suat hang nam (VD: 0.12 = 12%).
        months (int): So thang vay.

    Tra ve:
        tuple: (Tien tra moi thang, Tong tien lai phai tra).
    """
    # Kiem tra du lieu dau vao
    if principal <= 0:
        raise ValueError("So tien vay phai lon hon 0.")
    if annual_rate < 0:
        raise ValueError("Lai suat khong duoc am.")
    if not isinstance(months, int) or isinstance(months, bool) or months <= 0:
        raise ValueError("So thang vay phai la so nguyen duong.")

    # Chuyen lai suat nam thanh lai suat thang
    monthly_rate = annual_rate / 12

    # Neu lai suat bang 0 thi chi can chia deu tien goc
    if monthly_rate == 0:
        emi = principal / months
    else:
        # Ap dung cong thuc EMI
        factor = (1 + monthly_rate) ** months
        emi = principal * monthly_rate * factor / (factor - 1)

    # Tinh tong tien lai trong suot thoi gian vay
    total_interest = emi * months - principal

    # Tra ve 2 gia tri de su dung unpacking
    return emi, total_interest


# Chuong trinh chay thu theo de bai
print("=== BAI 1: TINH TIEN TRA GOP EMI ===")
principal = 1000000000  # Vay 1 ty VND
annual_rate = 0.12     # Lai suat 12%/nam
months = 12            # Thoi han 12 thang

# Nhan 2 gia tri tu ham bang unpacking
monthly_payment, total_interest = calculate_emi(principal, annual_rate, months)

print(f"So tien vay: {principal:,.0f} VND")
print(f"Lai suat: {annual_rate * 100:g}%/nam")
print(f"Thoi han: {months} thang")
print(f"Tra moi thang: {monthly_payment:,.0f} VND | Tong lai phai tra: {total_interest:,.0f} VND")
